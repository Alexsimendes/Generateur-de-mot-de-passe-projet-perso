package com.example.makepasswordsstrongagain.utils

enum class AppTheme {

    DARK, LIGHT

}
